
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
//import javax.lang.model.element.Element;
//import javax.lang.model.util.Elements;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class GoogleProject {

    


 public static ArrayList<String> sendList(String searchString) throws IOException {
        ArrayList<String> results = new ArrayList<>();
        String google = "http://www.google.com/search?q=";
         String charset = "UTF-8";
        String userAgent = "ExampleBot 1.0 (+http://example.com/bot)"; // Change this to your company's name and bot homepage!
        String url;
        System.out.println(google + URLEncoder.encode(searchString, charset));
        Document doc = Jsoup.connect(google + URLEncoder.encode(searchString, charset)).userAgent(userAgent).get();
        System.out.println(doc);
        Element searchResultCenterContent = doc.getElementById("center_col");
        System.out.println("start---------------------------------------");
        Elements top10SearchResults = searchResultCenterContent.getElementsByClass("srg");
        Elements links = searchResultCenterContent.getElementsByTag("a");
        
        /*
       for (Element link : links) {
            url = link.attr("abs:href");
            
            if (!url.contains("webcache") && url.contains("url")) {
                url = URLDecoder.decode(url.substring(url.indexOf('=') + 1, url.indexOf('&')), "UTF-8");
                if(!results.contains(url))
                    results.add(url);
               // System.out.println(url);
            }
        }
       //*/
        System.out.println("----ends------------------------------------");
        return results;
    }

    public static void main(String[] args) {
     try {
         int i=1;
         for(String x:sendList("messi")){
             System.out.println(i++ +" ------ "+x);
         }
         
         
     } catch (IOException ex) {
         Logger.getLogger(GoogleProject.class.getName()).log(Level.SEVERE, null, ex);
     }
    }
    
}
